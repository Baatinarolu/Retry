"use client";

import { useCallback, useEffect, useState } from "react";
import { FilterState, filterQuery } from "./Filters";

export const emptyFilters: FilterState = {
  from: "",
  to: "",
  accountId: "",
  instrument: "",
  strategyId: "",
  direction: "",
  session: "",
};

export function useWorkspace() {
  const [accounts, setAccounts] = useState<{ id: string; name: string; currency: string; currentBalance: string; startingBalance: string }[]>([]);
  const [instruments, setInstruments] = useState<{ symbol: string }[]>([]);
  const [strategies, setStrategies] = useState<{ id: string; name: string }[]>([]);
  const [currency, setCurrency] = useState("USD");
  const [filters, setFilters] = useState<FilterState>(emptyFilters);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([fetch("/api/bootstrap").then((r) => r.json()), fetch("/api/strategies").then((r) => r.json())]).then(
      ([boot, strat]) => {
        setAccounts(boot.accounts || []);
        setInstruments(boot.instruments || []);
        setStrategies((strat.strategies || []).map((s: { id: string; name: string }) => ({ id: s.id, name: s.name })));
        setCurrency(boot.user?.baseCurrency || boot.accounts?.[0]?.currency || "USD");
        setLoading(false);
      },
    );
  }, []);

  const qs = filterQuery(filters);
  const loadAnalytics = useCallback(() => fetch(`/api/analytics?${qs}`).then((r) => r.json()), [qs]);
  const loadTrades = useCallback(
    (page = 1, extra = "") => fetch(`/api/trades?page=${page}&limit=25&${qs}&${extra}`).then((r) => r.json()),
    [qs],
  );

  return {
    accounts,
    instruments: instruments.map((i) => i.symbol),
    strategies,
    currency,
    filters,
    setFilters,
    loading,
    qs,
    loadAnalytics,
    loadTrades,
  };
}
