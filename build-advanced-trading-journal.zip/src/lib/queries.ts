import { db } from "@/db";
import {
  psychologyRecords,
  strategies,
  tags,
  tradeTags,
  trades,
  tradingAccounts,
} from "@/db/schema";
import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import type { TradeRow } from "./analytics";

export type TradeFilters = {
  from?: string | null;
  to?: string | null;
  accountId?: string | null;
  instrument?: string | null;
  strategyId?: string | null;
  direction?: string | null;
  session?: string | null;
};

export function tradeWhere(userId: string, filters: TradeFilters = {}) {
  const parts = [eq(trades.userId, userId)];
  if (filters.accountId) parts.push(eq(trades.accountId, filters.accountId));
  if (filters.instrument) parts.push(eq(trades.instrument, filters.instrument));
  if (filters.strategyId) parts.push(eq(trades.strategyId, filters.strategyId));
  if (filters.direction) parts.push(eq(trades.direction, filters.direction));
  if (filters.session) parts.push(eq(trades.session, filters.session));
  if (filters.from) parts.push(gte(trades.entryAt, new Date(filters.from)));
  if (filters.to) {
    const end = new Date(filters.to);
    if (!filters.to.includes("T")) end.setUTCHours(23, 59, 59, 999);
    parts.push(lte(trades.entryAt, end));
  }
  return and(...parts);
}

export async function loadTradeRows(userId: string, filters: TradeFilters = {}): Promise<TradeRow[]> {
  const rows = await db
    .select({
      trade: trades,
      strategyName: strategies.name,
      psych: psychologyRecords,
    })
    .from(trades)
    .leftJoin(strategies, eq(strategies.id, trades.strategyId))
    .leftJoin(psychologyRecords, eq(psychologyRecords.tradeId, trades.id))
    .where(tradeWhere(userId, filters))
    .orderBy(desc(trades.entryAt));

  return rows.map((r) => ({
    id: r.trade.id,
    displayId: r.trade.displayId,
    instrument: r.trade.instrument,
    strategyId: r.trade.strategyId,
    strategyName: r.strategyName,
    session: r.trade.session,
    direction: r.trade.direction,
    tradeType: r.trade.tradeType,
    entryTimeframe: r.trade.entryTimeframe,
    followedPlan: r.trade.followedPlan,
    newsRelated: r.trade.newsRelated,
    notes: r.trade.notes,
    netPnl: r.trade.netPnl,
    grossPnl: r.trade.grossPnl,
    rMultiple: r.trade.rMultiple,
    result: r.trade.result,
    holdingMinutes: r.trade.holdingMinutes,
    entryAt: r.trade.entryAt,
    exitAt: r.trade.exitAt,
    emotionBefore: r.psych?.emotionBefore,
    emotionAfter: r.psych?.emotionAfter,
    fomo: r.psych?.fomo,
    revenge: r.psych?.revenge,
    earlyExit: r.psych?.earlyExit,
    movedStop: r.psych?.movedStop,
    brokeRiskRules: r.psych?.brokeRiskRules,
    impulsive: r.psych?.impulsive,
  }));
}

export async function nextDisplayId(userId: string) {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(trades)
    .where(eq(trades.userId, userId));
  const n = Number(count || 0) + 1;
  const year = new Date().getUTCFullYear();
  return `TM-${year}-${String(n).padStart(4, "0")}`;
}

export async function getUserAccounts(userId: string) {
  return db
    .select()
    .from(tradingAccounts)
    .where(eq(tradingAccounts.userId, userId))
    .orderBy(tradingAccounts.createdAt);
}

export async function getUserStrategies(userId: string) {
  return db.select().from(strategies).where(eq(strategies.userId, userId)).orderBy(strategies.name);
}

export async function getUserTags(userId: string) {
  return db.select().from(tags).where(eq(tags.userId, userId)).orderBy(tags.name);
}

export async function startingBalanceFor(userId: string, accountId?: string | null) {
  if (accountId) {
    const [a] = await db.select().from(tradingAccounts).where(and(eq(tradingAccounts.id, accountId), eq(tradingAccounts.userId, userId)));
    return a?.startingBalance ?? "0";
  }
  const list = await getUserAccounts(userId);
  return list.reduce((s, a) => s + Number(a.startingBalance || 0), 0).toFixed(2);
}

export async function attachTags(tradeId: string, tagIds: string[]) {
  if (!tagIds.length) return;
  await db.insert(tradeTags).values(tagIds.map((tagId) => ({ tradeId, tagId })));
}
