import { db } from "@/db";
import {
  psychologyRecords,
  screenshots,
  tradeExecutions,
  tradeTags,
  trades,
  tradingAccounts,
} from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { computeTradeMetrics, type Direction } from "./calculations";
import { attachTags, nextDisplayId } from "./queries";

export type TradePayload = {
  accountId: string;
  strategyId?: string | null;
  instrument: string;
  marketCategory?: string;
  direction: "long" | "short";
  tradeType?: string;
  session?: string;
  timezone?: string;
  entryAt: string;
  exitAt?: string | null;
  entryPrice?: string | number | null;
  exitPrice?: string | number | null;
  stopLoss?: string | number | null;
  takeProfit?: string | number | null;
  positionSize?: string | number | null;
  lotSize?: string | number | null;
  contractSize?: string | number | null;
  tickSize?: string | number | null;
  tickValue?: string | number | null;
  pipSize?: string | number | null;
  pipValue?: string | number | null;
  commission?: string | number | null;
  swap?: string | number | null;
  slippage?: string | number | null;
  overrideNetPnl?: string | number | null;
  pnlOverridden?: boolean;
  status?: "open" | "closed";
  marketBias?: string;
  htfDirection?: string;
  entryTimeframe?: string;
  htfTimeframe?: string;
  marketStructure?: string;
  entryModel?: string;
  confluence?: string;
  entryReason?: string;
  slJustification?: string;
  tpJustification?: string;
  invalidation?: string;
  plannedExit?: string;
  followedPlan?: boolean;
  newsRelated?: boolean;
  notes?: string;
  tagIds?: string[];
  executions?: {
    type: "entry" | "scale_in" | "scale_out" | "exit";
    price: string | number;
    quantity: string | number;
    executedAt: string;
    fees?: string | number;
    notes?: string;
  }[];
  psychology?: {
    emotionBefore?: string;
    emotionDuring?: string;
    emotionAfter?: string;
    confidence?: number;
    patience?: number;
    fomo?: boolean;
    fear?: boolean;
    greed?: boolean;
    revenge?: boolean;
    overtrading?: boolean;
    hesitation?: boolean;
    impulsive?: boolean;
    earlyExit?: boolean;
    movedStop?: boolean;
    brokeRiskRules?: boolean;
    followedPlan?: boolean;
    lessons?: string;
    didWell?: string;
    improve?: string;
    reflection?: string;
  };
};

function str(v: string | number | null | undefined) {
  if (v === null || v === undefined || v === "") return null;
  return String(v);
}

function str0(v: string | number | null | undefined) {
  if (v === null || v === undefined || v === "") return "0";
  return String(v);
}

export async function createTrade(userId: string, payload: TradePayload) {
  const [account] = await db
    .select()
    .from(tradingAccounts)
    .where(and(eq(tradingAccounts.id, payload.accountId), eq(tradingAccounts.userId, userId)));
  if (!account) throw new Error("Account not found");

  const entryAt = new Date(payload.entryAt);
  const exitAt = payload.exitAt ? new Date(payload.exitAt) : null;
  const metrics = computeTradeMetrics({
    direction: payload.direction as Direction,
    entryPrice: str0(payload.entryPrice),
    exitPrice: payload.status === "open" ? null : payload.exitPrice,
    stopLoss: payload.stopLoss,
    takeProfit: payload.takeProfit,
    positionSize: payload.positionSize,
    lotSize: payload.lotSize,
    contractSize: payload.contractSize,
    tickSize: payload.tickSize,
    tickValue: payload.tickValue,
    pipSize: payload.pipSize,
    pipValue: payload.pipValue,
    commission: payload.commission,
    swap: payload.swap,
    slippage: payload.slippage,
    overrideNetPnl: payload.pnlOverridden ? payload.overrideNetPnl : null,
    entryAt,
    exitAt,
  });

  const displayId = await nextDisplayId(userId);
  const balanceBefore = account.currentBalance;
  const closed = payload.status !== "open";
  const balanceAfter = closed
    ? (Number(balanceBefore) + Number(metrics.netPnl)).toFixed(2)
    : balanceBefore;

  const [trade] = await db
    .insert(trades)
    .values({
      userId,
      accountId: payload.accountId,
      strategyId: payload.strategyId || null,
      displayId,
      instrument: payload.instrument,
      marketCategory: payload.marketCategory || "forex",
      direction: payload.direction,
      tradeType: payload.tradeType || "intraday",
      session: payload.session || "london",
      timezone: payload.timezone || "UTC",
      entryAt,
      exitAt,
      entryPrice: str0(payload.entryPrice),
      exitPrice: str(payload.exitPrice),
      stopLoss: str(payload.stopLoss),
      takeProfit: str(payload.takeProfit),
      positionSize: str0(payload.positionSize || payload.lotSize || "1"),
      lotSize: str0(payload.lotSize || payload.positionSize || "1"),
      contractSize: str0(payload.contractSize || "1"),
      tickSize: str0(payload.tickSize),
      tickValue: str0(payload.tickValue),
      pipSize: str0(payload.pipSize || "0.0001"),
      pipValue: str0(payload.pipValue || "10"),
      commission: str0(payload.commission),
      swap: str0(payload.swap),
      slippage: str0(payload.slippage),
      grossPnl: metrics.grossPnl,
      netPnl: closed ? metrics.netPnl : "0",
      initialRisk: metrics.initialRisk,
      plannedRr: metrics.plannedRr,
      actualRr: closed ? metrics.actualRr : null,
      rMultiple: closed ? metrics.rMultiple : null,
      balanceBefore,
      balanceAfter,
      status: closed ? "closed" : "open",
      result: closed ? metrics.result : "be",
      marketBias: payload.marketBias || "",
      htfDirection: payload.htfDirection || "",
      entryTimeframe: payload.entryTimeframe || "15m",
      htfTimeframe: payload.htfTimeframe || "4h",
      marketStructure: payload.marketStructure || "",
      entryModel: payload.entryModel || "",
      confluence: payload.confluence || "",
      entryReason: payload.entryReason || "",
      slJustification: payload.slJustification || "",
      tpJustification: payload.tpJustification || "",
      invalidation: payload.invalidation || "",
      plannedExit: payload.plannedExit || "",
      followedPlan: payload.followedPlan ?? true,
      newsRelated: payload.newsRelated ?? false,
      notes: payload.notes || "",
      holdingMinutes: metrics.holdingMinutes,
      pnlOverridden: payload.pnlOverridden ?? false,
    })
    .returning();

  if (closed) {
    await db
      .update(tradingAccounts)
      .set({ currentBalance: balanceAfter, updatedAt: new Date() })
      .where(eq(tradingAccounts.id, account.id));
  }

  if (payload.executions?.length) {
    await db.insert(tradeExecutions).values(
      payload.executions.map((e) => ({
        tradeId: trade.id,
        userId,
        type: e.type,
        price: String(e.price),
        quantity: String(e.quantity),
        executedAt: new Date(e.executedAt),
        fees: String(e.fees || 0),
        notes: e.notes || "",
      })),
    );
  }

  if (payload.tagIds?.length) await attachTags(trade.id, payload.tagIds);

  if (payload.psychology) {
    const p = payload.psychology;
    await db.insert(psychologyRecords).values({
      tradeId: trade.id,
      userId,
      emotionBefore: p.emotionBefore || "",
      emotionDuring: p.emotionDuring || "",
      emotionAfter: p.emotionAfter || "",
      confidence: p.confidence ?? 5,
      patience: p.patience ?? 5,
      fomo: p.fomo ?? false,
      fear: p.fear ?? false,
      greed: p.greed ?? false,
      revenge: p.revenge ?? false,
      overtrading: p.overtrading ?? false,
      hesitation: p.hesitation ?? false,
      impulsive: p.impulsive ?? false,
      earlyExit: p.earlyExit ?? false,
      movedStop: p.movedStop ?? false,
      brokeRiskRules: p.brokeRiskRules ?? false,
      followedPlan: p.followedPlan ?? payload.followedPlan ?? true,
      lessons: p.lessons || "",
      didWell: p.didWell || "",
      improve: p.improve || "",
      reflection: p.reflection || "",
    });
  }

  return trade;
}

export async function updateTrade(userId: string, tradeId: string, payload: TradePayload) {
  const [existing] = await db
    .select()
    .from(trades)
    .where(and(eq(trades.id, tradeId), eq(trades.userId, userId)));
  if (!existing) return null;

  const [account] = await db
    .select()
    .from(tradingAccounts)
    .where(and(eq(tradingAccounts.id, payload.accountId), eq(tradingAccounts.userId, userId)));
  if (!account) throw new Error("Account not found");

  const entryAt = new Date(payload.entryAt);
  const exitAt = payload.exitAt ? new Date(payload.exitAt) : null;
  const metrics = computeTradeMetrics({
    direction: payload.direction as Direction,
    entryPrice: str0(payload.entryPrice),
    exitPrice: payload.status === "open" ? null : payload.exitPrice,
    stopLoss: payload.stopLoss,
    takeProfit: payload.takeProfit,
    positionSize: payload.positionSize,
    lotSize: payload.lotSize,
    contractSize: payload.contractSize,
    tickSize: payload.tickSize,
    tickValue: payload.tickValue,
    pipSize: payload.pipSize,
    pipValue: payload.pipValue,
    commission: payload.commission,
    swap: payload.swap,
    slippage: payload.slippage,
    overrideNetPnl: payload.pnlOverridden ? payload.overrideNetPnl : null,
    entryAt,
    exitAt,
  });

  const closed = payload.status !== "open";
  const oldNet = existing.status === "closed" ? Number(existing.netPnl) : 0;
  const newNet = closed ? Number(metrics.netPnl) : 0;
  const newBalance = (Number(account.currentBalance) - oldNet + newNet).toFixed(2);

  const [trade] = await db
    .update(trades)
    .set({
      accountId: payload.accountId,
      strategyId: payload.strategyId || null,
      instrument: payload.instrument,
      marketCategory: payload.marketCategory || existing.marketCategory,
      direction: payload.direction,
      tradeType: payload.tradeType || existing.tradeType,
      session: payload.session || existing.session,
      timezone: payload.timezone || existing.timezone,
      entryAt,
      exitAt,
      entryPrice: str0(payload.entryPrice),
      exitPrice: str(payload.exitPrice),
      stopLoss: str(payload.stopLoss),
      takeProfit: str(payload.takeProfit),
      positionSize: str0(payload.positionSize || payload.lotSize || "1"),
      lotSize: str0(payload.lotSize || payload.positionSize || "1"),
      contractSize: str0(payload.contractSize || existing.contractSize),
      tickSize: str0(payload.tickSize || existing.tickSize),
      tickValue: str0(payload.tickValue || existing.tickValue),
      pipSize: str0(payload.pipSize || existing.pipSize),
      pipValue: str0(payload.pipValue || existing.pipValue),
      commission: str0(payload.commission),
      swap: str0(payload.swap),
      slippage: str0(payload.slippage),
      grossPnl: metrics.grossPnl,
      netPnl: closed ? metrics.netPnl : "0",
      initialRisk: metrics.initialRisk,
      plannedRr: metrics.plannedRr,
      actualRr: closed ? metrics.actualRr : null,
      rMultiple: closed ? metrics.rMultiple : null,
      balanceAfter: newBalance,
      status: closed ? "closed" : "open",
      result: closed ? metrics.result : "be",
      marketBias: payload.marketBias ?? existing.marketBias,
      htfDirection: payload.htfDirection ?? existing.htfDirection,
      entryTimeframe: payload.entryTimeframe ?? existing.entryTimeframe,
      htfTimeframe: payload.htfTimeframe ?? existing.htfTimeframe,
      marketStructure: payload.marketStructure ?? existing.marketStructure,
      entryModel: payload.entryModel ?? existing.entryModel,
      confluence: payload.confluence ?? existing.confluence,
      entryReason: payload.entryReason ?? existing.entryReason,
      slJustification: payload.slJustification ?? existing.slJustification,
      tpJustification: payload.tpJustification ?? existing.tpJustification,
      invalidation: payload.invalidation ?? existing.invalidation,
      plannedExit: payload.plannedExit ?? existing.plannedExit,
      followedPlan: payload.followedPlan ?? existing.followedPlan,
      newsRelated: payload.newsRelated ?? existing.newsRelated,
      notes: payload.notes ?? existing.notes,
      holdingMinutes: metrics.holdingMinutes,
      pnlOverridden: payload.pnlOverridden ?? false,
      updatedAt: new Date(),
    })
    .where(eq(trades.id, tradeId))
    .returning();

  await db
    .update(tradingAccounts)
    .set({ currentBalance: newBalance, updatedAt: new Date() })
    .where(eq(tradingAccounts.id, account.id));

  await db.delete(tradeTags).where(eq(tradeTags.tradeId, tradeId));
  if (payload.tagIds?.length) await attachTags(tradeId, payload.tagIds);

  await db.delete(tradeExecutions).where(eq(tradeExecutions.tradeId, tradeId));
  if (payload.executions?.length) {
    await db.insert(tradeExecutions).values(
      payload.executions.map((e) => ({
        tradeId,
        userId,
        type: e.type,
        price: String(e.price),
        quantity: String(e.quantity),
        executedAt: new Date(e.executedAt),
        fees: String(e.fees || 0),
        notes: e.notes || "",
      })),
    );
  }

  if (payload.psychology) {
    const p = payload.psychology;
    const [existingP] = await db.select().from(psychologyRecords).where(eq(psychologyRecords.tradeId, tradeId));
    const values = {
      emotionBefore: p.emotionBefore || "",
      emotionDuring: p.emotionDuring || "",
      emotionAfter: p.emotionAfter || "",
      confidence: p.confidence ?? 5,
      patience: p.patience ?? 5,
      fomo: p.fomo ?? false,
      fear: p.fear ?? false,
      greed: p.greed ?? false,
      revenge: p.revenge ?? false,
      overtrading: p.overtrading ?? false,
      hesitation: p.hesitation ?? false,
      impulsive: p.impulsive ?? false,
      earlyExit: p.earlyExit ?? false,
      movedStop: p.movedStop ?? false,
      brokeRiskRules: p.brokeRiskRules ?? false,
      followedPlan: p.followedPlan ?? payload.followedPlan ?? true,
      lessons: p.lessons || "",
      didWell: p.didWell || "",
      improve: p.improve || "",
      reflection: p.reflection || "",
    };
    if (existingP) {
      await db.update(psychologyRecords).set(values).where(eq(psychologyRecords.id, existingP.id));
    } else {
      await db.insert(psychologyRecords).values({ tradeId, userId, ...values });
    }
  }

  return trade;
}

export async function deleteTrade(userId: string, tradeId: string) {
  const [existing] = await db
    .select()
    .from(trades)
    .where(and(eq(trades.id, tradeId), eq(trades.userId, userId)));
  if (!existing) return false;
  if (existing.status === "closed") {
    const [account] = await db.select().from(tradingAccounts).where(eq(tradingAccounts.id, existing.accountId));
    if (account) {
      const restored = (Number(account.currentBalance) - Number(existing.netPnl)).toFixed(2);
      await db.update(tradingAccounts).set({ currentBalance: restored, updatedAt: new Date() }).where(eq(tradingAccounts.id, account.id));
    }
  }
  await db.delete(screenshots).where(eq(screenshots.tradeId, tradeId));
  await db.delete(trades).where(eq(trades.id, tradeId));
  return true;
}
