import { NextResponse } from "next/server";
import { getSession } from "./auth";

export async function requireUser() {
  const session = await getSession();
  if (!session) {
    return { session: null as null, error: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { session, error: null };
}

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function parseFilters(url: URL) {
  return {
    from: url.searchParams.get("from"),
    to: url.searchParams.get("to"),
    accountId: url.searchParams.get("accountId"),
    instrument: url.searchParams.get("instrument"),
    strategyId: url.searchParams.get("strategyId"),
    direction: url.searchParams.get("direction"),
    session: url.searchParams.get("session"),
  };
}
