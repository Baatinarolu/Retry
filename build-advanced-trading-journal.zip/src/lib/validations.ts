import { z } from "zod";

export const signupSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email().max(160),
  password: z.string().min(8).max(120),
  timezone: z.string().max(80).optional(),
  baseCurrency: z.string().max(8).optional(),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const forgotSchema = z.object({
  email: z.string().email(),
});

export const resetSchema = z.object({
  token: z.string().min(10),
  password: z.string().min(8).max(120),
});

export const accountSchema = z.object({
  name: z.string().min(1).max(80),
  broker: z.string().max(80).optional().default(""),
  currency: z.string().min(3).max(8),
  startingBalance: z.string().or(z.number()),
  accountType: z.enum(["live", "demo", "prop", "paper"]).optional().default("live"),
  notes: z.string().max(2000).optional().default(""),
  isActive: z.boolean().optional().default(true),
});

const numish = z.union([z.string(), z.number(), z.null()]).optional();

export const tradeSchema = z.object({
  accountId: z.string().uuid(),
  strategyId: z.string().uuid().nullable().optional(),
  instrument: z.string().min(1).max(32),
  marketCategory: z.string().max(32).optional().default("forex"),
  direction: z.enum(["long", "short"]),
  tradeType: z.string().max(32).optional().default("intraday"),
  session: z.string().max(40).optional().default("london"),
  timezone: z.string().max(80).optional().default("UTC"),
  entryAt: z.string(),
  exitAt: z.string().nullable().optional(),
  entryPrice: numish,
  exitPrice: numish,
  stopLoss: numish,
  takeProfit: numish,
  positionSize: numish,
  lotSize: numish,
  contractSize: numish,
  tickSize: numish,
  tickValue: numish,
  pipSize: numish,
  pipValue: numish,
  commission: numish,
  swap: numish,
  slippage: numish,
  overrideNetPnl: numish,
  pnlOverridden: z.boolean().optional().default(false),
  status: z.enum(["open", "closed"]).optional().default("closed"),
  marketBias: z.string().optional().default(""),
  htfDirection: z.string().optional().default(""),
  entryTimeframe: z.string().optional().default("15m"),
  htfTimeframe: z.string().optional().default("4h"),
  marketStructure: z.string().optional().default(""),
  entryModel: z.string().optional().default(""),
  confluence: z.string().optional().default(""),
  entryReason: z.string().optional().default(""),
  slJustification: z.string().optional().default(""),
  tpJustification: z.string().optional().default(""),
  invalidation: z.string().optional().default(""),
  plannedExit: z.string().optional().default(""),
  followedPlan: z.boolean().optional().default(true),
  newsRelated: z.boolean().optional().default(false),
  notes: z.string().optional().default(""),
  tagIds: z.array(z.string().uuid()).optional().default([]),
  executions: z
    .array(
      z.object({
        type: z.enum(["entry", "scale_in", "scale_out", "exit"]),
        price: z.union([z.string(), z.number()]),
        quantity: z.union([z.string(), z.number()]),
        executedAt: z.string(),
        fees: z.union([z.string(), z.number()]).optional(),
        notes: z.string().optional(),
      }),
    )
    .optional()
    .default([]),
  psychology: z
    .object({
      emotionBefore: z.string().optional().default(""),
      emotionDuring: z.string().optional().default(""),
      emotionAfter: z.string().optional().default(""),
      confidence: z.number().int().min(1).max(10).optional().default(5),
      patience: z.number().int().min(1).max(10).optional().default(5),
      fomo: z.boolean().optional().default(false),
      fear: z.boolean().optional().default(false),
      greed: z.boolean().optional().default(false),
      revenge: z.boolean().optional().default(false),
      overtrading: z.boolean().optional().default(false),
      hesitation: z.boolean().optional().default(false),
      impulsive: z.boolean().optional().default(false),
      earlyExit: z.boolean().optional().default(false),
      movedStop: z.boolean().optional().default(false),
      brokeRiskRules: z.boolean().optional().default(false),
      followedPlan: z.boolean().optional().default(true),
      lessons: z.string().optional().default(""),
      didWell: z.string().optional().default(""),
      improve: z.string().optional().default(""),
      reflection: z.string().optional().default(""),
    })
    .optional(),
});

export const strategySchema = z.object({
  name: z.string().min(1).max(120),
  description: z.string().optional().default(""),
  marketConditions: z.string().optional().default(""),
  confirmations: z.string().optional().default(""),
  entryRules: z.string().optional().default(""),
  stopLossRules: z.string().optional().default(""),
  takeProfitRules: z.string().optional().default(""),
  riskRules: z.string().optional().default(""),
  invalidation: z.string().optional().default(""),
  checklist: z.array(z.string()).optional().default([]),
});

export const journalSchema = z.object({
  journalDate: z.string(),
  accountId: z.string().uuid().nullable().optional(),
  notes: z.string().optional().default(""),
  mood: z.string().optional().default(""),
  mistakes: z.string().optional().default(""),
  grade: z.string().optional().default(""),
  followedRules: z.boolean().optional().default(true),
});

export const backtestSchema = z.object({
  name: z.string().min(1).max(120),
  instrument: z.string().min(1),
  timeframe: z.string().optional().default("15m"),
  strategyId: z.string().uuid().nullable().optional(),
  startDate: z.string(),
  endDate: z.string(),
  session: z.string().optional().default(""),
  entryRules: z.string().optional().default(""),
  exitRules: z.string().optional().default(""),
  riskModel: z.string().optional().default(""),
  notes: z.string().optional().default(""),
});

export const backtestTradeSchema = z.object({
  instrument: z.string().min(1),
  direction: z.enum(["long", "short"]),
  entryAt: z.string(),
  exitAt: z.string().nullable().optional(),
  entryPrice: z.union([z.string(), z.number()]),
  exitPrice: z.union([z.string(), z.number()]).nullable().optional(),
  stopLoss: z.union([z.string(), z.number()]).nullable().optional(),
  takeProfit: z.union([z.string(), z.number()]).nullable().optional(),
  resultR: z.union([z.string(), z.number()]).optional().default("0"),
  resultCurrency: z.union([z.string(), z.number()]).optional().default("0"),
  informationAtDecision: z.string().optional().default(""),
  notes: z.string().optional().default(""),
  followedRules: z.boolean().optional().default(true),
});

export const riskSchema = z.object({
  accountId: z.string().uuid().nullable().optional(),
  defaultRiskPercent: z.union([z.string(), z.number()]).optional(),
  maxDailyLoss: z.union([z.string(), z.number()]).optional(),
  maxWeeklyLoss: z.union([z.string(), z.number()]).optional(),
  maxTradesPerDay: z.number().int().optional(),
  maxConsecutiveLosses: z.number().int().optional(),
  maxOpenRisk: z.union([z.string(), z.number()]).optional(),
  minPlannedRr: z.union([z.string(), z.number()]).optional(),
  dailyProfitTarget: z.union([z.string(), z.number()]).optional(),
  maxPositionSize: z.union([z.string(), z.number()]).optional(),
  personalRules: z.string().optional(),
});

export const settingsSchema = z.object({
  name: z.string().min(2).max(80).optional(),
  timezone: z.string().optional(),
  theme: z.enum(["dark", "light"]).optional(),
  dateFormat: z.string().optional(),
  timeFormat: z.string().optional(),
  baseCurrency: z.string().optional(),
  aiPermission: z.boolean().optional(),
});

export const instrumentSchema = z.object({
  symbol: z.string().min(1).max(24),
  name: z.string().min(1).max(80),
  category: z.string().optional().default("forex"),
  contractSize: z.union([z.string(), z.number()]).optional(),
  tickSize: z.union([z.string(), z.number()]).optional(),
  tickValue: z.union([z.string(), z.number()]).optional(),
  pipSize: z.union([z.string(), z.number()]).optional(),
  pipValue: z.union([z.string(), z.number()]).optional(),
  quoteCurrency: z.string().optional().default("USD"),
  notes: z.string().optional().default(""),
});
