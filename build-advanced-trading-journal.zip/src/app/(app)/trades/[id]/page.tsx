"use client";

import { TradeForm } from "@/components/TradeForm";
import { Banner, Button, Spinner } from "@/components/ui";
import { formatMoney, formatR, formatWhen, pnlClass } from "@/lib/format";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function TradeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [trade, setTrade] = useState<any>(null);
  const [editing, setEditing] = useState(false);
  const [zoom, setZoom] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/trades/${id}`).then((r) => r.json()).then((d) => setTrade(d.trade));
  }, [id]);

  if (!trade) return <Spinner />;

  async function remove() {
    if (!confirm("Delete this trade? This cannot be undone.")) return;
    await fetch(`/api/trades/${id}`, { method: "DELETE" });
    router.push("/journal");
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.12em] text-[var(--muted)]">{trade.displayId}</p>
          <h1 className="text-2xl font-semibold">
            {trade.instrument} {trade.direction}
          </h1>
          <p className="text-sm text-[var(--muted)]">
            {formatWhen(trade.entryAt)} → {formatWhen(trade.exitAt)} · {trade.session}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => setEditing((v) => !v)}>{editing ? "Close editor" : "Edit"}</Button>
          <Button variant="danger" onClick={remove}>Delete</Button>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-4">
        <div className="card-quiet p-4"><p className="text-xs text-[var(--muted)]">Net P&L</p><p className={`font-mono-num text-xl ${pnlClass(trade.netPnl)}`}>{formatMoney(trade.netPnl)}</p></div>
        <div className="card-quiet p-4"><p className="text-xs text-[var(--muted)]">R</p><p className="font-mono-num text-xl">{formatR(trade.rMultiple)}</p></div>
        <div className="card-quiet p-4"><p className="text-xs text-[var(--muted)]">Result</p><p className="text-xl capitalize">{trade.result}</p></div>
        <div className="card-quiet p-4"><p className="text-xs text-[var(--muted)]">Plan</p><p className="text-xl">{trade.followedPlan ? "Followed" : "Broke"}</p></div>
      </div>
      {trade.notes ? <Banner>{trade.notes}</Banner> : null}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {(trade.screenshots || []).map((s: any) => (
          <button key={s.id} onClick={() => setZoom(s.id)} className="card-quiet overflow-hidden text-left">
            <img src={`/api/screenshots/${s.id}`} alt={s.caption} className="h-40 w-full object-cover" />
            <p className="px-3 py-2 text-xs text-[var(--muted)]">{s.category} {s.caption}</p>
          </button>
        ))}
      </div>
      {zoom ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-6" onClick={() => setZoom(null)}>
          <img src={`/api/screenshots/${zoom}`} alt="" className="max-h-full max-w-full rounded-xl" />
        </div>
      ) : null}
      {trade.psychology ? (
        <section className="card p-5 text-sm">
          <h2 className="mb-2 font-semibold">Psychology</h2>
          <p>Before {trade.psychology.emotionBefore} · during {trade.psychology.emotionDuring} · after {trade.psychology.emotionAfter}</p>
          <p className="mt-2 text-[var(--muted)]">{trade.psychology.reflection || trade.psychology.lessons}</p>
        </section>
      ) : null}
      {editing ? <TradeForm tradeId={id} /> : null}
    </div>
  );
}
