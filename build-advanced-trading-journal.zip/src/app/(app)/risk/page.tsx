"use client";

import { Banner, Button, Card, Field, Input, Textarea } from "@/components/ui";
import { formatMoney } from "@/lib/format";
import { useEffect, useState } from "react";

export default function RiskPage() {
  const [settings, setSettings] = useState<any>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [check, setCheck] = useState<any>(null);
  const [form, setForm] = useState({ plannedRisk: "50", plannedRr: "2", positionSize: "0.5" });

  useEffect(() => {
    fetch("/api/risk").then((r) => r.json()).then((d) => setSettings(d.settings));
    fetch("/api/accounts").then((r) => r.json()).then((d) => setAccounts(d.accounts || []));
  }, []);

  async function save() {
    await fetch("/api/risk", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    });
  }

  async function preview() {
    const d = await fetch("/api/risk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, accountId: settings?.accountId }),
    }).then((r) => r.json());
    setCheck(d);
  }

  if (!settings) return null;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold">Risk management</h1>
        <p className="text-sm text-[var(--muted)]">Limits are warnings only. This app never places or modifies broker orders.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="space-y-3">
          <h2 className="font-semibold">Rules</h2>
          <Field label="Default risk %"><Input value={settings.defaultRiskPercent} onChange={(e) => setSettings({ ...settings, defaultRiskPercent: e.target.value })} /></Field>
          <Field label="Max daily loss"><Input value={settings.maxDailyLoss} onChange={(e) => setSettings({ ...settings, maxDailyLoss: e.target.value })} /></Field>
          <Field label="Max weekly loss"><Input value={settings.maxWeeklyLoss} onChange={(e) => setSettings({ ...settings, maxWeeklyLoss: e.target.value })} /></Field>
          <Field label="Max trades / day"><Input type="number" value={settings.maxTradesPerDay} onChange={(e) => setSettings({ ...settings, maxTradesPerDay: Number(e.target.value) })} /></Field>
          <Field label="Max consecutive losses"><Input type="number" value={settings.maxConsecutiveLosses} onChange={(e) => setSettings({ ...settings, maxConsecutiveLosses: Number(e.target.value) })} /></Field>
          <Field label="Min planned R:R"><Input value={settings.minPlannedRr} onChange={(e) => setSettings({ ...settings, minPlannedRr: e.target.value })} /></Field>
          <Field label="Daily profit target (optional)"><Input value={settings.dailyProfitTarget} onChange={(e) => setSettings({ ...settings, dailyProfitTarget: e.target.value })} /></Field>
          <Field label="Max position size"><Input value={settings.maxPositionSize} onChange={(e) => setSettings({ ...settings, maxPositionSize: e.target.value })} /></Field>
          <Field label="Personal rules"><Textarea value={settings.personalRules} onChange={(e) => setSettings({ ...settings, personalRules: e.target.value })} /></Field>
          <Button onClick={save}>Save rules</Button>
        </Card>
        <Card className="space-y-3">
          <h2 className="font-semibold">Pre-trade check</h2>
          <Field label="Planned monetary risk"><Input value={form.plannedRisk} onChange={(e) => setForm({ ...form, plannedRisk: e.target.value })} /></Field>
          <Field label="Planned R:R"><Input value={form.plannedRr} onChange={(e) => setForm({ ...form, plannedRr: e.target.value })} /></Field>
          <Field label="Position size"><Input value={form.positionSize} onChange={(e) => setForm({ ...form, positionSize: e.target.value })} /></Field>
          <Button onClick={preview}>Check against rules</Button>
          {check ? (
            <div className="space-y-2 text-sm">
              <p>Today P&L {formatMoney(check.dailyPnl)} · trades {check.tradesToday} · loss streak {check.consecutiveLosses}</p>
              {check.remainingDailyLoss !== null ? <p>Remaining daily loss allowance {formatMoney(check.remainingDailyLoss)}</p> : null}
              {check.warnings?.length ? check.warnings.map((w: string) => <Banner key={w} tone="warn">{w}</Banner>) : <Banner tone="good">No rule violations detected for this hypothetical size.</Banner>}
            </div>
          ) : null}
          <div className="pt-4">
            <h3 className="font-medium">Accounts</h3>
            <ul className="mt-2 space-y-1 text-sm">
              {accounts.map((a) => (
                <li key={a.id}>{a.name} · {a.currency} · start {formatMoney(a.startingBalance, a.currency)} · now {formatMoney(a.currentBalance, a.currency)}</li>
              ))}
            </ul>
          </div>
        </Card>
      </div>
    </div>
  );
}
