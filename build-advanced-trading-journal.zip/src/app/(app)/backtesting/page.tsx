"use client";

import { Banner, Button, Card, Field, Input, Select, Textarea } from "@/components/ui";
import { formatR } from "@/lib/format";
import { useEffect, useState } from "react";

export default function BacktestingPage() {
  const [list, setList] = useState<any[]>([]);
  const [active, setActive] = useState<any>(null);
  const [trades, setTrades] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [form, setForm] = useState({
    name: "",
    instrument: "EURUSD",
    timeframe: "15m",
    startDate: "2025-01-01",
    endDate: "2025-03-31",
    session: "london",
    entryRules: "",
    exitRules: "",
    riskModel: "0.5% simulated, 1R stop",
    notes: "",
  });
  const [row, setRow] = useState({
    instrument: "EURUSD",
    direction: "long",
    entryAt: new Date().toISOString().slice(0, 16),
    exitAt: new Date().toISOString().slice(0, 16),
    entryPrice: "",
    exitPrice: "",
    resultR: "1",
    resultCurrency: "0",
    informationAtDecision: "",
    notes: "",
  });

  function reloadList() {
    fetch("/api/backtests").then((r) => r.json()).then((d) => setList(d.backtests || []));
  }
  useEffect(reloadList, []);

  async function open(id: string) {
    const d = await fetch(`/api/backtests?id=${id}`).then((r) => r.json());
    setActive(d.backtest);
    setTrades(d.trades || []);
    setStats(d.stats);
  }

  async function create(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/backtests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await res.json();
    reloadList();
    if (d.backtest) open(d.backtest.id);
  }

  async function addTrade(e: React.FormEvent) {
    e.preventDefault();
    if (!active) return;
    await fetch("/api/backtests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        backtestId: active.id,
        ...row,
        entryAt: new Date(row.entryAt).toISOString(),
        exitAt: row.exitAt ? new Date(row.exitAt).toISOString() : null,
      }),
    });
    open(active.id);
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold">Manual backtesting journal</h1>
        <p className="text-sm text-[var(--muted)]">Simulated results are stored separately from live trades. This is not a historical candle replay engine and does not hide future bars.</p>
      </div>
      <Banner tone="warn">Record only information available at the decision. Look-ahead bias is a process error, not a feature.</Banner>
      <div className="grid gap-4 lg:grid-cols-[0.9fr_1.2fr]">
        <Card>
          <h2 className="mb-3 font-semibold">New backtest</h2>
          <form onSubmit={create} className="space-y-3">
            <Field label="Name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></Field>
            <Field label="Instrument"><Input value={form.instrument} onChange={(e) => setForm({ ...form, instrument: e.target.value })} /></Field>
            <Field label="Timeframe"><Input value={form.timeframe} onChange={(e) => setForm({ ...form, timeframe: e.target.value })} /></Field>
            <Field label="Start"><Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></Field>
            <Field label="End"><Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></Field>
            <Field label="Entry rules"><Textarea value={form.entryRules} onChange={(e) => setForm({ ...form, entryRules: e.target.value })} /></Field>
            <Field label="Exit rules"><Textarea value={form.exitRules} onChange={(e) => setForm({ ...form, exitRules: e.target.value })} /></Field>
            <Field label="Risk model"><Input value={form.riskModel} onChange={(e) => setForm({ ...form, riskModel: e.target.value })} /></Field>
            <Button type="submit">Create</Button>
          </form>
          <ul className="mt-5 space-y-2 text-sm">
            {list.map((b) => (
              <li key={b.id}>
                <button className="text-teal-300" onClick={() => open(b.id)}>{b.name} · {b.instrument}</button>
              </li>
            ))}
          </ul>
        </Card>
        <Card>
          {!active ? <p className="text-sm text-[var(--muted)]">Select a backtest.</p> : null}
          {active ? (
            <div className="space-y-4">
              <div>
                <p className="text-xs uppercase tracking-[0.12em] text-amber-300">Simulated</p>
                <h2 className="text-xl font-semibold">{active.name}</h2>
                <p className="text-sm text-[var(--muted)]">{active.instrument} {active.timeframe} · {active.startDate} → {active.endDate}</p>
              </div>
              {stats ? (
                <div className="grid grid-cols-2 gap-2 text-sm md:grid-cols-4">
                  <div className="card-quiet p-3">n={stats.totalTrades}</div>
                  <div className="card-quiet p-3">WR {(stats.winRate ? stats.winRate * 100 : 0).toFixed(1)}%</div>
                  <div className="card-quiet p-3">Exp {stats.expectancyR ?? "n/a"}R</div>
                  <div className="card-quiet p-3">PF {stats.profitFactor ?? "n/a"}</div>
                </div>
              ) : null}
              <form onSubmit={addTrade} className="grid gap-2 md:grid-cols-2">
                <Field label="Direction">
                  <Select value={row.direction} onChange={(e) => setRow({ ...row, direction: e.target.value })}>
                    <option value="long">Long</option>
                    <option value="short">Short</option>
                  </Select>
                </Field>
                <Field label="Result R"><Input value={row.resultR} onChange={(e) => setRow({ ...row, resultR: e.target.value })} /></Field>
                <Field label="Entry"><Input type="datetime-local" value={row.entryAt} onChange={(e) => setRow({ ...row, entryAt: e.target.value })} /></Field>
                <Field label="What was known then"><Input value={row.informationAtDecision} onChange={(e) => setRow({ ...row, informationAtDecision: e.target.value })} /></Field>
                <Button type="submit">Log simulated trade</Button>
              </form>
              <ul className="space-y-2 text-sm">
                {trades.map((t) => (
                  <li key={t.id} className="flex justify-between border-b border-[var(--border)] py-2">
                    <span>{t.direction} · {t.informationAtDecision || t.notes}</span>
                    <span>{formatR(t.resultR)}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </Card>
      </div>
    </div>
  );
}
