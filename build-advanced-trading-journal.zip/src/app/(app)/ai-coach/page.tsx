"use client";

import { Banner, Button, Card, Field, Spinner, Textarea } from "@/components/ui";
import { useEffect, useState } from "react";

export default function AiCoachPage() {
  const [question, setQuestion] = useState("");
  const [review, setReview] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [permission, setPermission] = useState(false);

  useEffect(() => {
    fetch("/api/ai").then((r) => r.json()).then((d) => setHistory(d.reviews || []));
    fetch("/api/settings").then((r) => r.json()).then((d) => setPermission(Boolean(d.user?.aiPermission)));
  }, []);

  async function run(type: string) {
    setLoading(true);
    const res = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, question }),
    });
    const data = await res.json();
    setLoading(false);
    setReview(data.review);
    if (data.review) setHistory((h) => [data.review, ...h]);
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold">AI Coach</h1>
        <p className="text-sm text-[var(--muted)]">
          Default reviews are generated from your journal statistics on this server. They cannot predict markets or promise profitability.
        </p>
      </div>
      {!permission ? (
        <Banner tone="warn">
          External language models are off until you enable AI permission in Settings. Rule-based coaching still works and never leaves this app.
        </Banner>
      ) : (
        <Banner>You allowed sending summarized journal statistics to an external model when an API key is configured.</Banner>
      )}
      <Card className="space-y-3">
        <Field label="Ask about your journal">
          <Textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Why am I repeatedly losing on US30? Which ICT setups performed best? Do I move stops?"
          />
        </Field>
        <div className="flex flex-wrap gap-2">
          <Button loading={loading} onClick={() => run("review")}>Review sample</Button>
          <Button variant="ghost" loading={loading} onClick={() => run("weekly")}>Weekly</Button>
          <Button variant="ghost" loading={loading} onClick={() => run("monthly")}>Monthly</Button>
          <Button variant="ghost" loading={loading} onClick={() => run("psychology")}>Psychology</Button>
        </div>
      </Card>
      {review ? (
        <Card>
          <p className="text-xs uppercase tracking-[0.12em] text-[var(--muted)]">
            {review.source === "llm" ? "External model" : "Rule-based"} · n={review.sampleSize}
          </p>
          <pre className="mt-3 whitespace-pre-wrap font-sans text-sm leading-6">{review.content}</pre>
        </Card>
      ) : loading ? (
        <Spinner label="Analyzing journal facts" />
      ) : null}
      <Card>
        <h2 className="mb-3 font-semibold">History</h2>
        <ul className="space-y-2 text-sm">
          {history.map((h) => (
            <li key={h.id}>
              <button className="text-left text-teal-300" onClick={() => setReview(h)}>
                {h.type} · {new Date(h.createdAt).toLocaleString()} · {h.source}
              </button>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
