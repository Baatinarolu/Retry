"use client";

import { Banner, Card, Spinner, Stat } from "@/components/ui";
import { useWorkspace } from "@/components/useWorkspace";
import { formatMoney, pnlClass } from "@/lib/format";
import { useEffect, useState } from "react";

export default function PsychologyPage() {
  const ws = useWorkspace();
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    if (ws.loading) return;
    ws.loadAnalytics().then(setData);
  }, [ws.loading, ws.qs]);
  if (!data) return <Spinner />;
  const a = data.analytics;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold">Psychology</h1>
        <p className="text-sm text-[var(--muted)]">Emotional tags vs outcomes. These are journal correlations, not diagnoses or market predictions.</p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <Stat label="Rule following" value={a.stats.ruleFollowingPct === null ? "—" : `${a.stats.ruleFollowingPct}%`} />
        <Stat label="Plan-break trades" value={a.byPlan.find((p: any) => p.key.startsWith("Broke"))?.stats.totalTrades ?? 0} />
        <Stat label="Tagged mistakes" value={a.mistakes.reduce((s: number, m: any) => s + m.count, 0)} />
      </div>
      <Card>
        <h2 className="mb-3 font-semibold">Emotion before entry</h2>
        <ul className="grid gap-2 md:grid-cols-2">
          {a.byEmotion.map((r: any) => (
            <li key={r.key} className="flex justify-between card-quiet p-3 text-sm">
              <span>{r.label} n={r.stats.totalTrades}{r.sampleWarning ? " · small n" : ""}</span>
              <span className={pnlClass(r.stats.netPnl)}>{formatMoney(r.stats.netPnl, ws.currency)}</span>
            </li>
          ))}
        </ul>
      </Card>
      <Card>
        <h2 className="mb-3 font-semibold">Costliest process tags</h2>
        {a.mistakes.length === 0 ? <p className="text-sm text-[var(--muted)]">Tag mistakes on the trade form to populate this view.</p> : null}
        <ul className="space-y-2">
          {a.mistakes.map((m: any) => (
            <li key={m.label} className="flex justify-between text-sm">
              <span>{m.label} × {m.count}</span>
              <span className={pnlClass(m.netPnl)}>{formatMoney(m.netPnl, ws.currency)}</span>
            </li>
          ))}
        </ul>
      </Card>
      <Banner>
        After a losing streak, review size and rules before the next click. Revenge size and martingale are never part of this coach.
      </Banner>
    </div>
  );
}
