import { db } from "@/db";
import { tags } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { and, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const { session, error } = await requireUser();
  if (error) return error;
  const list = await db.select().from(tags).where(eq(tags.userId, session!.uid));
  return NextResponse.json({ tags: list });
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const body = await req.json().catch(() => null);
  if (!body?.name) return jsonError("Name required");
  try {
    const [tag] = await db
      .insert(tags)
      .values({
        userId: session!.uid,
        name: String(body.name).trim(),
        category: body.category || "custom",
        color: body.color || "#2dd4bf",
      })
      .returning();
    return NextResponse.json({ tag }, { status: 201 });
  } catch {
    return jsonError("Tag already exists");
  }
}

export async function DELETE(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return jsonError("id required");
  await db.delete(tags).where(and(eq(tags.id, id), eq(tags.userId, session!.uid)));
  return NextResponse.json({ ok: true });
}
