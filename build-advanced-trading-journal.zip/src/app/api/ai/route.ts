import { db } from "@/db";
import { aiReviews, users } from "@/db/schema";
import { jsonError, parseFilters, requireUser } from "@/lib/api";
import { buildAnalytics, ruleBasedCoach } from "@/lib/analytics";
import { loadTradeRows, startingBalanceFor } from "@/lib/queries";
import { desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const { session, error } = await requireUser();
  if (error) return error;
  const reviews = await db
    .select()
    .from(aiReviews)
    .where(eq(aiReviews.userId, session!.uid))
    .orderBy(desc(aiReviews.createdAt))
    .limit(20);
  return NextResponse.json({ reviews });
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const body = await req.json().catch(() => ({}));
  const type = String(body.type || "review");
  const question = typeof body.question === "string" ? body.question : "";
  const filters = parseFilters(new URL(req.url));
  if (body.from) filters.from = body.from;
  if (body.to) filters.to = body.to;
  const rows = await loadTradeRows(session!.uid, filters);
  const starting = await startingBalanceFor(session!.uid, filters.accountId);
  const analytics = buildAnalytics(rows, starting);
  const facts = ruleBasedCoach({
    question,
    stats: analytics.stats,
    insights: analytics.insights,
    byInstrument: analytics.byInstrument,
    bySession: analytics.bySession,
    byStrategy: analytics.byStrategy,
    mistakes: analytics.mistakes,
    sampleSize: rows.length,
    dateFrom: filters.from,
    dateTo: filters.to,
  });

  const [user] = await db.select().from(users).where(eq(users.id, session!.uid));
  let content = facts;
  let source = "rules";
  const apiKey = process.env.OPENAI_API_KEY;
  if (apiKey && user?.aiPermission) {
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          temperature: 0.2,
          messages: [
            {
              role: "system",
              content:
                "You are TradeMind Coach, a trading journal analyst. Use only the provided journal statistics. Never invent trades, prices, or news. Never promise profits. Never encourage martingale, revenge trading, or uncontrolled leverage. Distinguish facts from hypotheses. If sample size is small, say so. Do not give live buy/sell signals.",
            },
            {
              role: "user",
              content: `${facts}\n\nWrite a concise coaching review with facts vs hypotheses, then 5 process questions. User question: ${question || "(none)"}`,
            },
          ],
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
        const text = data.choices?.[0]?.message?.content;
        if (text) {
          content = text;
          source = "llm";
        }
      }
    } catch {
      source = "rules";
    }
  } else if (apiKey && !user?.aiPermission) {
    content = `${facts}\n\nAI provider was not used. Enable AI permission in Settings before sending journal summaries to an external model.`;
  }

  const [review] = await db
    .insert(aiReviews)
    .values({
      userId: session!.uid,
      type,
      dateFrom: filters.from || null,
      dateTo: filters.to || null,
      sampleSize: rows.length,
      content,
      source,
    })
    .returning();

  return NextResponse.json({ review, usedLlm: source === "llm" });
}
