import { db } from "@/db";
import {
  psychologyRecords,
  screenshots,
  strategies,
  tags,
  tradeExecutions,
  tradeTags,
  trades,
} from "@/db/schema";
import { jsonError, parseFilters, requireUser } from "@/lib/api";
import { tradeWhere } from "@/lib/queries";
import { createTrade } from "@/lib/trade-service";
import { tradeSchema } from "@/lib/validations";
import { desc, eq, inArray } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const url = new URL(req.url);
  const filters = parseFilters(url);
  const page = Math.max(1, Number(url.searchParams.get("page") || 1));
  const limit = Math.min(100, Math.max(1, Number(url.searchParams.get("limit") || 25)));
  const q = url.searchParams.get("q")?.trim().toLowerCase();
  const offset = (page - 1) * limit;

  const rows = await db
    .select({ trade: trades, strategyName: strategies.name })
    .from(trades)
    .leftJoin(strategies, eq(strategies.id, trades.strategyId))
    .where(tradeWhere(session!.uid, filters))
    .orderBy(desc(trades.entryAt));

  const filtered = q
    ? rows.filter(
        (r) =>
          r.trade.instrument.toLowerCase().includes(q) ||
          r.trade.displayId.toLowerCase().includes(q) ||
          r.trade.notes.toLowerCase().includes(q) ||
          (r.strategyName || "").toLowerCase().includes(q),
      )
    : rows;

  const slice = filtered.slice(offset, offset + limit);
  const ids = slice.map((r) => r.trade.id);
  const tagRows = ids.length
    ? await db
        .select({ tradeId: tradeTags.tradeId, tag: tags })
        .from(tradeTags)
        .innerJoin(tags, eq(tags.id, tradeTags.tagId))
        .where(inArray(tradeTags.tradeId, ids))
    : [];
  const shots = ids.length
    ? await db.select().from(screenshots).where(inArray(screenshots.tradeId, ids))
    : [];

  return NextResponse.json({
    total: filtered.length,
    page,
    limit,
    trades: slice.map((r) => ({
      ...r.trade,
      strategyName: r.strategyName,
      tags: tagRows.filter((t) => t.tradeId === r.trade.id).map((t) => t.tag),
      screenshotCount: shots.filter((s) => s.tradeId === r.trade.id).length,
    })),
  });
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const body = await req.json().catch(() => null);
  const parsed = tradeSchema.safeParse(body);
  if (!parsed.success) return jsonError(parsed.error.issues[0]?.message || "Invalid trade payload");
  try {
    const trade = await createTrade(session!.uid, parsed.data);
    return NextResponse.json({ trade }, { status: 201 });
  } catch (e) {
    return jsonError(e instanceof Error ? e.message : "Could not save trade", 400);
  }
}
