import { db } from "@/db";
import { screenshots, trades } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { ALLOWED_IMAGE_TYPES, MAX_UPLOAD_BYTES } from "@/lib/constants";
import { and, eq } from "drizzle-orm";
import { mkdir, writeFile } from "fs/promises";
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { nanoid } from "nanoid";

export const dynamic = "force-dynamic";

const ROOT = path.join(process.cwd(), "data", "uploads");

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { session, error } = await requireUser();
  if (error) return error;
  const { id } = await ctx.params;
  const [trade] = await db
    .select()
    .from(trades)
    .where(and(eq(trades.id, id), eq(trades.userId, session!.uid)));
  if (!trade) return jsonError("Trade not found", 404);

  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) return jsonError("Image file is required");
  if (file.size > MAX_UPLOAD_BYTES) return jsonError("Image must be 5MB or smaller");
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) return jsonError("Only JPEG, PNG, WebP, and GIF are allowed");

  const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : file.type === "image/gif" ? "gif" : "jpg";
  const fileName = `${nanoid()}.${ext}`;
  const dir = path.join(ROOT, session!.uid);
  await mkdir(dir, { recursive: true });
  const buf = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(dir, fileName), buf);

  const [shot] = await db
    .insert(screenshots)
    .values({
      tradeId: id,
      userId: session!.uid,
      category: String(form.get("category") || "entry"),
      caption: String(form.get("caption") || ""),
      fileName,
      mimeType: file.type,
      sizeBytes: file.size,
    })
    .returning();

  return NextResponse.json({ screenshot: shot }, { status: 201 });
}
