import { db } from "@/db";
import { users } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { settingsSchema } from "@/lib/validations";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const { session, error } = await requireUser();
  if (error) return error;
  const [user] = await db.select().from(users).where(eq(users.id, session!.uid));
  if (!user) return jsonError("Not found", 404);
  const { passwordHash: _p, ...safe } = user;
  return NextResponse.json({ user: safe });
}

export async function PATCH(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const parsed = settingsSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return jsonError("Invalid settings");
  const [user] = await db
    .update(users)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(users.id, session!.uid))
    .returning();
  const { passwordHash: _p, ...safe } = user;
  return NextResponse.json({ user: safe });
}

export async function DELETE() {
  const { session, error } = await requireUser();
  if (error) return error;
  const { clearSessionCookie } = await import("@/lib/auth");
  await db.delete(users).where(eq(users.id, session!.uid));
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
