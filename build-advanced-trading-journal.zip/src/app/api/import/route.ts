import { db } from "@/db";
import { trades, tradingAccounts } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { createTrade } from "@/lib/trade-service";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type PreviewRow = {
  line: number;
  data: Record<string, string>;
  errors: string[];
  duplicate: boolean;
};

function parseCsv(text: string): { headers: string[]; rows: Record<string, string>[]; lineMap: number[] } {
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter((l) => l.trim().length);
  if (!lines.length) return { headers: [], rows: [], lineMap: [] };
  const split = (line: string) => {
    const out: string[] = [];
    let cur = "";
    let q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (q && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else q = !q;
      } else if (ch === "," && !q) {
        out.push(cur.trim());
        cur = "";
      } else cur += ch;
    }
    out.push(cur.trim());
    return out;
  };
  const headers = split(lines[0]).map((h) => h.toLowerCase().replace(/\s+/g, "_"));
  const rows: Record<string, string>[] = [];
  const lineMap: number[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = split(lines[i]);
    const rec: Record<string, string> = {};
    headers.forEach((h, idx) => {
      rec[h] = cols[idx] ?? "";
    });
    rows.push(rec);
    lineMap.push(i + 1);
  }
  return { headers, rows, lineMap };
}

const ALIASES: Record<string, string[]> = {
  instrument: ["instrument", "symbol", "ticker", "pair"],
  direction: ["direction", "side", "type", "buy_sell"],
  entryAt: ["entry_at", "entry_time", "open_time", "time", "date"],
  exitAt: ["exit_at", "exit_time", "close_time"],
  entryPrice: ["entry_price", "open_price", "open"],
  exitPrice: ["exit_price", "close_price", "close"],
  stopLoss: ["stop_loss", "sl"],
  takeProfit: ["take_profit", "tp"],
  lotSize: ["lot_size", "lots", "volume", "size", "qty"],
  commission: ["commission", "fee", "fees"],
  swap: ["swap", "swap_fee", "funding"],
  netPnl: ["net_pnl", "pnl", "profit", "net"],
  session: ["session"],
};

function pick(row: Record<string, string>, key: string) {
  const names = ALIASES[key] || [key];
  for (const n of names) {
    if (row[n] !== undefined && row[n] !== "") return row[n];
  }
  return "";
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const body = await req.json().catch(() => null);
  if (!body) return jsonError("Invalid payload");

  const accounts = await db.select().from(tradingAccounts).where(eq(tradingAccounts.userId, session!.uid));
  const account = accounts.find((a) => a.id === body.accountId) || accounts[0];
  if (!account) return jsonError("Create an account first");

  if (body.csv === undefined && !body.rows) return jsonError("csv required");

  if (body.commit && Array.isArray(body.rows)) {
    const created: string[] = [];
    const rejected: { line: number; error: string }[] = [];
    for (const row of body.rows as PreviewRow[]) {
      if (row.errors.length || row.duplicate) {
        rejected.push({ line: row.line, error: row.errors.join("; ") || "duplicate" });
        continue;
      }
      const d = row.data;
      try {
        const trade = await createTrade(session!.uid, {
          accountId: account.id,
          instrument: d.instrument,
          direction: d.direction === "short" || d.direction === "sell" ? "short" : "long",
          entryAt: d.entryAt,
          exitAt: d.exitAt || null,
          entryPrice: d.entryPrice,
          exitPrice: d.exitPrice,
          stopLoss: d.stopLoss || null,
          takeProfit: d.takeProfit || null,
          lotSize: d.lotSize || "1",
          positionSize: d.lotSize || "1",
          commission: d.commission || "0",
          swap: d.swap || "0",
          pnlOverridden: Boolean(d.netPnl),
          overrideNetPnl: d.netPnl || null,
          session: d.session || "other",
          notes: "Imported from CSV",
          status: d.exitAt ? "closed" : "open",
        });
        created.push(trade.displayId);
      } catch (e) {
        rejected.push({ line: row.line, error: e instanceof Error ? e.message : "failed" });
      }
    }
    return NextResponse.json({ created, rejected, imported: created.length });
  }

  const { rows, lineMap, headers } = parseCsv(String(body.csv || ""));
  const saved = await db.select().from(trades).where(eq(trades.userId, session!.uid));

  const preview: PreviewRow[] = rows.map((raw, idx) => {
    const instrument = pick(raw, "instrument");
    const directionRaw = pick(raw, "direction").toLowerCase();
    const direction = directionRaw.includes("sell") || directionRaw.includes("short") ? "short" : directionRaw.includes("buy") || directionRaw.includes("long") ? "long" : "";
    const entryAt = pick(raw, "entryAt");
    const exitAt = pick(raw, "exitAt");
    const entryPrice = pick(raw, "entryPrice");
    const exitPrice = pick(raw, "exitPrice");
    const errors: string[] = [];
    if (!instrument) errors.push("Missing instrument");
    if (!direction) errors.push("Missing direction");
    if (!entryAt || Number.isNaN(new Date(entryAt).getTime())) errors.push("Invalid entry time");
    if (!entryPrice) errors.push("Missing entry price");
    const duplicate = saved.some(
      (t) =>
        t.instrument === instrument &&
        t.direction === direction &&
        Math.abs(t.entryAt.getTime() - new Date(entryAt).getTime()) < 60000,
    );
    return {
      line: lineMap[idx],
      data: {
        instrument,
        direction,
        entryAt,
        exitAt,
        entryPrice,
        exitPrice,
        stopLoss: pick(raw, "stopLoss"),
        takeProfit: pick(raw, "takeProfit"),
        lotSize: pick(raw, "lotSize") || "1",
        commission: pick(raw, "commission") || "0",
        swap: pick(raw, "swap") || "0",
        netPnl: pick(raw, "netPnl"),
        session: pick(raw, "session"),
      },
      errors,
      duplicate,
    };
  });

  return NextResponse.json({
    headers,
    preview,
    valid: preview.filter((p) => !p.errors.length && !p.duplicate).length,
    rejected: preview.filter((p) => p.errors.length || p.duplicate).length,
  });
}
