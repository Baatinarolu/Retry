import { db } from "@/db";
import { psychologyRecords, strategies, trades } from "@/db/schema";
import { parseFilters, requireUser } from "@/lib/api";
import { tradeWhere } from "@/lib/queries";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const url = new URL(req.url);
  const format = url.searchParams.get("format") || "csv";
  const filters = parseFilters(url);
  const rows = await db
    .select({ trade: trades, strategyName: strategies.name, psych: psychologyRecords })
    .from(trades)
    .leftJoin(strategies, eq(strategies.id, trades.strategyId))
    .leftJoin(psychologyRecords, eq(psychologyRecords.tradeId, trades.id))
    .where(tradeWhere(session!.uid, filters));

  if (format === "json") {
    return NextResponse.json({
      exportedAt: new Date().toISOString(),
      trades: rows.map((r) => ({ ...r.trade, strategyName: r.strategyName, psychology: r.psych })),
    });
  }

  const headers = [
    "display_id",
    "instrument",
    "direction",
    "entry_at",
    "exit_at",
    "entry_price",
    "exit_price",
    "stop_loss",
    "take_profit",
    "lot_size",
    "commission",
    "swap",
    "gross_pnl",
    "net_pnl",
    "r_multiple",
    "result",
    "session",
    "strategy",
    "followed_plan",
    "notes",
  ];
  const lines = [headers.join(",")];
  for (const r of rows) {
    const t = r.trade;
    const vals = [
      t.displayId,
      t.instrument,
      t.direction,
      t.entryAt.toISOString(),
      t.exitAt ? t.exitAt.toISOString() : "",
      t.entryPrice,
      t.exitPrice ?? "",
      t.stopLoss ?? "",
      t.takeProfit ?? "",
      t.lotSize,
      t.commission,
      t.swap,
      t.grossPnl,
      t.netPnl,
      t.rMultiple ?? "",
      t.result,
      t.session,
      r.strategyName ?? "",
      String(t.followedPlan),
      `"${(t.notes || "").replace(/"/g, '""')}"`,
    ];
    lines.push(vals.join(","));
  }
  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="trademind-export.csv"`,
    },
  });
}
