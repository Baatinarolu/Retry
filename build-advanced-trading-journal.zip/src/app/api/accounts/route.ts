import { db } from "@/db";
import { riskSettings, tradingAccounts } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { accountSchema } from "@/lib/validations";
import { and, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const { session, error } = await requireUser();
  if (error) return error;
  const accounts = await db
    .select()
    .from(tradingAccounts)
    .where(eq(tradingAccounts.userId, session!.uid));
  return NextResponse.json({ accounts });
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const parsed = accountSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return jsonError("Invalid account");
  const starting = String(parsed.data.startingBalance);
  const [account] = await db
    .insert(tradingAccounts)
    .values({
      userId: session!.uid,
      name: parsed.data.name,
      broker: parsed.data.broker || "",
      currency: parsed.data.currency,
      startingBalance: starting,
      currentBalance: starting,
      accountType: parsed.data.accountType || "live",
      notes: parsed.data.notes || "",
      isActive: parsed.data.isActive ?? true,
    })
    .returning();
  await db.insert(riskSettings).values({ userId: session!.uid, accountId: account.id });
  return NextResponse.json({ account }, { status: 201 });
}

export async function PATCH(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const body = await req.json().catch(() => null);
  if (!body?.id) return jsonError("id required");
  const [existing] = await db
    .select()
    .from(tradingAccounts)
    .where(and(eq(tradingAccounts.id, body.id), eq(tradingAccounts.userId, session!.uid)));
  if (!existing) return jsonError("Not found", 404);
  const [account] = await db
    .update(tradingAccounts)
    .set({
      name: body.name ?? existing.name,
      broker: body.broker ?? existing.broker,
      currency: body.currency ?? existing.currency,
      accountType: body.accountType ?? existing.accountType,
      notes: body.notes ?? existing.notes,
      isActive: body.isActive ?? existing.isActive,
      startingBalance: body.startingBalance ? String(body.startingBalance) : existing.startingBalance,
      updatedAt: new Date(),
    })
    .where(eq(tradingAccounts.id, existing.id))
    .returning();
  return NextResponse.json({ account });
}

export async function DELETE(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return jsonError("id required");
  const [existing] = await db
    .select()
    .from(tradingAccounts)
    .where(and(eq(tradingAccounts.id, id), eq(tradingAccounts.userId, session!.uid)));
  if (!existing) return jsonError("Not found", 404);
  try {
    await db.delete(tradingAccounts).where(eq(tradingAccounts.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return jsonError("Cannot delete an account that still has trades. Archive it instead.");
  }
}
