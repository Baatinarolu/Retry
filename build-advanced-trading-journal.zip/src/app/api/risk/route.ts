import { db } from "@/db";
import { riskSettings, trades } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { riskSchema } from "@/lib/validations";
import { and, eq, gte } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const accountId = new URL(req.url).searchParams.get("accountId");
  const list = await db.select().from(riskSettings).where(eq(riskSettings.userId, session!.uid));
  const settings = accountId ? list.find((r) => r.accountId === accountId) || list[0] : list[0];
  return NextResponse.json({ settings, all: list });
}

export async function PATCH(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const parsed = riskSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return jsonError("Invalid risk settings");
  const list = await db.select().from(riskSettings).where(eq(riskSettings.userId, session!.uid));
  const current = parsed.data.accountId
    ? list.find((r) => r.accountId === parsed.data.accountId)
    : list[0];
  if (!current) return jsonError("No risk profile yet", 404);
  const [row] = await db
    .update(riskSettings)
    .set({
      defaultRiskPercent: parsed.data.defaultRiskPercent ? String(parsed.data.defaultRiskPercent) : current.defaultRiskPercent,
      maxDailyLoss: parsed.data.maxDailyLoss ? String(parsed.data.maxDailyLoss) : current.maxDailyLoss,
      maxWeeklyLoss: parsed.data.maxWeeklyLoss ? String(parsed.data.maxWeeklyLoss) : current.maxWeeklyLoss,
      maxTradesPerDay: parsed.data.maxTradesPerDay ?? current.maxTradesPerDay,
      maxConsecutiveLosses: parsed.data.maxConsecutiveLosses ?? current.maxConsecutiveLosses,
      maxOpenRisk: parsed.data.maxOpenRisk ? String(parsed.data.maxOpenRisk) : current.maxOpenRisk,
      minPlannedRr: parsed.data.minPlannedRr ? String(parsed.data.minPlannedRr) : current.minPlannedRr,
      dailyProfitTarget: parsed.data.dailyProfitTarget ? String(parsed.data.dailyProfitTarget) : current.dailyProfitTarget,
      maxPositionSize: parsed.data.maxPositionSize ? String(parsed.data.maxPositionSize) : current.maxPositionSize,
      personalRules: parsed.data.personalRules ?? current.personalRules,
      updatedAt: new Date(),
    })
    .where(eq(riskSettings.id, current.id))
    .returning();
  return NextResponse.json({ settings: row });
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireUser();
  if (error) return error;
  const body = await req.json().catch(() => ({}));
  const accountId = body.accountId as string | undefined;
  const plannedRisk = Number(body.plannedRisk || 0);
  const plannedRr = Number(body.plannedRr || 0);
  const list = await db.select().from(riskSettings).where(eq(riskSettings.userId, session!.uid));
  const settings = accountId ? list.find((r) => r.accountId === accountId) || list[0] : list[0];
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const week = new Date(start);
  week.setUTCDate(week.getUTCDate() - week.getUTCDay());
  const todayTrades = await db
    .select()
    .from(trades)
    .where(and(eq(trades.userId, session!.uid), gte(trades.entryAt, start)));
  const weekTrades = await db
    .select()
    .from(trades)
    .where(and(eq(trades.userId, session!.uid), gte(trades.entryAt, week)));
  const dailyPnl = todayTrades.reduce((s, t) => s + Number(t.netPnl), 0);
  const weeklyPnl = weekTrades.reduce((s, t) => s + Number(t.netPnl), 0);
  let streak = 0;
  const sorted = [...todayTrades].sort((a, b) => b.entryAt.getTime() - a.entryAt.getTime());
  for (const t of sorted) {
    if (t.result === "loss") streak += 1;
    else break;
  }
  const warnings: string[] = [];
  if (settings) {
    if (Number(settings.maxDailyLoss) > 0 && dailyPnl - plannedRisk <= -Number(settings.maxDailyLoss)) {
      warnings.push("This idea may exceed the maximum daily loss.");
    }
    if (Number(settings.maxWeeklyLoss) > 0 && weeklyPnl - plannedRisk <= -Number(settings.maxWeeklyLoss)) {
      warnings.push("This idea may exceed the maximum weekly loss.");
    }
    if (todayTrades.length >= settings.maxTradesPerDay) {
      warnings.push("Maximum trades per day already reached.");
    }
    if (streak >= settings.maxConsecutiveLosses) {
      warnings.push("Consecutive loss limit already reached.");
    }
    if (Number(settings.minPlannedRr) > 0 && plannedRr > 0 && plannedRr < Number(settings.minPlannedRr)) {
      warnings.push(`Planned R:R ${plannedRr.toFixed(2)} is below your minimum ${settings.minPlannedRr}.`);
    }
    if (Number(settings.maxPositionSize) > 0 && Number(body.positionSize || 0) > Number(settings.maxPositionSize)) {
      warnings.push("Position size exceeds the configured maximum.");
    }
  }
  return NextResponse.json({
    warnings,
    remainingDailyLoss:
      settings && Number(settings.maxDailyLoss) > 0 ? Number(settings.maxDailyLoss) + dailyPnl : null,
    tradesToday: todayTrades.length,
    consecutiveLosses: streak,
    dailyPnl,
    weeklyPnl,
    settings,
  });
}
