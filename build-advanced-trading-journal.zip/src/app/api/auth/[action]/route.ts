import { db } from "@/db";
import { passwordResetTokens, users } from "@/db/schema";
import { clearSessionCookie, hashPassword, rateLimit, setSessionCookie, verifyPassword } from "@/lib/auth";
import { seedDemoTrades } from "@/lib/demo-data";
import { provisionNewUser } from "@/lib/onboarding";
import { forgotSchema, loginSchema, resetSchema, signupSchema } from "@/lib/validations";
import { createHash, randomBytes } from "crypto";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

function ipOf(req: NextRequest) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  const limited = rateLimit(`auth:${action}:${ipOf(req)}`, action === "login" ? 12 : 20, 60_000);
  if (!limited.ok) return NextResponse.json({ error: "Too many attempts. Try again shortly." }, { status: 429 });

  if (action === "logout") {
    await clearSessionCookie();
    return NextResponse.json({ ok: true });
  }

  if (action === "demo") {
    const email = "demo@trademind.app";
    let [user] = await db.select().from(users).where(eq(users.email, email));
    if (!user) {
      const passwordHash = await hashPassword("demo-trademind");
      [user] = await db
        .insert(users)
        .values({
          email,
          passwordHash,
          name: "Demo Trader",
          emailVerified: true,
          timezone: "Africa/Lagos",
          baseCurrency: "USD",
          demoMode: true,
          onboardingComplete: true,
        })
        .returning();
      await provisionNewUser(user.id, "USD");
    }
    await seedDemoTrades(user.id);
    await setSessionCookie({ uid: user.id, email: user.email, name: user.name });
    return NextResponse.json({ ok: true, demo: true, user: { id: user.id, email: user.email, name: user.name, demoMode: true } });
  }

  const body = await req.json().catch(() => ({}));

  if (action === "signup") {
    const parsed = signupSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Check name, email, and password (min 8 characters)." }, { status: 400 });
    const email = parsed.data.email.toLowerCase().trim();
    const [exists] = await db.select().from(users).where(eq(users.email, email));
    if (exists) return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
    const passwordHash = await hashPassword(parsed.data.password);
    const [user] = await db
      .insert(users)
      .values({
        email,
        passwordHash,
        name: parsed.data.name.trim(),
        emailVerified: true,
        timezone: parsed.data.timezone || "Africa/Lagos",
        baseCurrency: parsed.data.baseCurrency || "USD",
        onboardingComplete: true,
      })
      .returning();
    await provisionNewUser(user.id, user.baseCurrency);
    await setSessionCookie({ uid: user.id, email: user.email, name: user.name });
    return NextResponse.json({ ok: true, user: { id: user.id, email: user.email, name: user.name } });
  }

  if (action === "login") {
    const parsed = loginSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Invalid credentials." }, { status: 400 });
    const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email.toLowerCase().trim()));
    if (!user) return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    const ok = await verifyPassword(parsed.data.password, user.passwordHash);
    if (!ok) return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    await setSessionCookie({ uid: user.id, email: user.email, name: user.name });
    return NextResponse.json({ ok: true, user: { id: user.id, email: user.email, name: user.name, demoMode: user.demoMode } });
  }

  if (action === "forgot") {
    const parsed = forgotSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Enter a valid email." }, { status: 400 });
    const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email.toLowerCase().trim()));
    if (!user) {
      return NextResponse.json({
        ok: true,
        message: "If that email exists, a reset token was issued. In this environment tokens are shown only for accounts that exist.",
      });
    }
    const raw = randomBytes(24).toString("hex");
    const tokenHash = createHash("sha256").update(raw).digest("hex");
    await db.insert(passwordResetTokens).values({
      userId: user.id,
      tokenHash,
      expiresAt: new Date(Date.now() + 1000 * 60 * 30),
    });
    return NextResponse.json({
      ok: true,
      message: "Password reset token created. Email delivery is not configured in this sandbox, so the token is returned once.",
      token: raw,
      resetPath: `/reset-password?token=${raw}`,
    });
  }

  if (action === "reset") {
    const parsed = resetSchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Token and new password required." }, { status: 400 });
    const tokenHash = createHash("sha256").update(parsed.data.token).digest("hex");
    const [row] = await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.tokenHash, tokenHash));
    if (!row || row.usedAt || row.expiresAt.getTime() < Date.now()) {
      return NextResponse.json({ error: "Reset token is invalid or expired." }, { status: 400 });
    }
    const passwordHash = await hashPassword(parsed.data.password);
    await db.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, row.userId));
    await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, row.id));
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 404 });
}

export async function GET(_req: NextRequest, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  if (action !== "me") return NextResponse.json({ error: "Unknown action" }, { status: 404 });
  const { getSession } = await import("@/lib/auth");
  const session = await getSession();
  if (!session) return NextResponse.json({ user: null }, { status: 401 });
  const [user] = await db.select().from(users).where(eq(users.id, session.uid));
  if (!user) return NextResponse.json({ user: null }, { status: 401 });
  return NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      timezone: user.timezone,
      theme: user.theme,
      dateFormat: user.dateFormat,
      timeFormat: user.timeFormat,
      baseCurrency: user.baseCurrency,
      aiPermission: user.aiPermission,
      demoMode: user.demoMode,
    },
  });
}
