import { db } from "@/db";
import { screenshots } from "@/db/schema";
import { jsonError, requireUser } from "@/lib/api";
import { and, eq } from "drizzle-orm";
import { readFile, unlink } from "fs/promises";
import { NextRequest, NextResponse } from "next/server";
import path from "path";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { session, error } = await requireUser();
  if (error) return error;
  const { id } = await ctx.params;
  const [shot] = await db
    .select()
    .from(screenshots)
    .where(and(eq(screenshots.id, id), eq(screenshots.userId, session!.uid)));
  if (!shot) return jsonError("Not found", 404);
  const filePath = path.join(process.cwd(), "data", "uploads", session!.uid, shot.fileName);
  try {
    const buf = await readFile(filePath);
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        "Content-Type": shot.mimeType,
        "Cache-Control": "private, max-age=3600",
      },
    });
  } catch {
    return jsonError("File missing", 404);
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { session, error } = await requireUser();
  if (error) return error;
  const { id } = await ctx.params;
  const [shot] = await db
    .select()
    .from(screenshots)
    .where(and(eq(screenshots.id, id), eq(screenshots.userId, session!.uid)));
  if (!shot) return jsonError("Not found", 404);
  await db.delete(screenshots).where(eq(screenshots.id, id));
  try {
    await unlink(path.join(process.cwd(), "data", "uploads", session!.uid, shot.fileName));
  } catch {
    /* already gone */
  }
  return NextResponse.json({ ok: true });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { session, error } = await requireUser();
  if (error) return error;
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const [shot] = await db
    .select()
    .from(screenshots)
    .where(and(eq(screenshots.id, id), eq(screenshots.userId, session!.uid)));
  if (!shot) return jsonError("Not found", 404);
  const [updated] = await db
    .update(screenshots)
    .set({
      caption: typeof body.caption === "string" ? body.caption : shot.caption,
      category: typeof body.category === "string" ? body.category : shot.category,
    })
    .where(eq(screenshots.id, id))
    .returning();
  return NextResponse.json({ screenshot: updated });
}
